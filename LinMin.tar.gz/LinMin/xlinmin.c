/* gcc -Wall -std=c99 -pedantic -o xlinmin xlinmin.c nrutil-ansi.c mnbrak.c brent.c f1dim.c frprmn.c linmin.c -lm */
/* Compiler executable checksum: aa420de397aec2b7ab2a7ae25509eb7e */
/* packed with 3-d_quadratic.txt Sat, Oct 12 2019 by Jonathan Engwall */
/* Tijuana, MX */
#include <stdio.h>
#include <gsl/gsl_sf_bessel.h>
#include <math.h>
#include "nr.h"
#include "nrutil.h"

#define NDIM 3
#define PIO2 1.5707963

float func(float x[])
{
	int i;
	float f=0.0;
	for (i=1;i<=3;i++) f += (2*x[i]+4.0)*(5*x[i]+3.0);
	return f;
}
int main(void)
{
	int i,j;
	float fret,sr2,x,*p,*xi;
	p=vector(1,NDIM);
	xi=vector(1,NDIM);
	printf("\nMinimum of a 3-d quadratic centered\n");
	printf("at (1.0,1.0,1.0). Minimum is found\n");
	printf("along a series of radials.\n\n");
	printf("%9s %11s %11s %13s \n","x","y","z","minimum");
	for (i=0;i<=750000;i++) {
		x=PIO2*i/10.0;
		sr2=sqrt(2.0);
		xi[1]=sr2*cos(x);
		xi[2]=sr2*sin(x);
		xi[3]=1.0;
		p[1]=p[2]=p[3]=0.0;
		linmin(p,xi,NDIM,&fret,func);
		for (j=1;j<=3;j++) printf("%12.6f",p[j]);
		printf("%12.6f\n",fret);
	}
	free_vector(xi,1,NDIM);
	free_vector(p,1,NDIM);
	return 0;
}
